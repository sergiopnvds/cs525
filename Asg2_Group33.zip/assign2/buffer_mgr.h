#ifndef BUFFER_MANAGER_H
#define BUFFER_MANAGER_H

// Include return codes and methods for logging errors
#include "dberror.h"
#include "storage_mgr.h"

// Include bool DT
#include "dt.h"

// Replacement Strategies
typedef enum ReplacementStrategy {
  RS_FIFO = 0,
  RS_LRU = 1,
  RS_CLOCK = 2,
  RS_LFU = 3,
  RS_LRU_K = 4
} ReplacementStrategy;

// Data Types and Structures
typedef int PageNumber;
#define NO_PAGE -1

typedef struct BM_BufferPool {
  char *pageFile;
  int numPages;
  ReplacementStrategy strategy;
  void *mgmtData; // use this one to store the bookkeeping info your buffer 
                  // manager needs for a buffer pool
} BM_BufferPool;

typedef struct BM_PageHandle {
  PageNumber pageNum;
  char *data;
} BM_PageHandle;

// STRUCTURES ADDED IN ASSIGNMENT 2
// Structure with data for buffer pool management
typedef struct BM_Mgmtdata{
  int numReadIO; // File reading counter
  int numWriteIO; //File writing counter
  SM_FileHandle fileHandle; // File handler related with buffer
  void* buffer; // Buffer structure.
} BM_Mgmtdata;

//Structure with buffer management data
typedef struct BM_Buffer{
  SM_PageHandle* frameBuffer; // Buffer array with frames
  int *pageIndex; // Array relating buffer position and page number
  int *fixCount; // Array relating buffer position and number of page fixes
  bool *dirtyFlags; // Array relating buffer position and marked dirty flags
  int insertPos; // Insertion position for FIFO buffer
  long *lastUseTime; // Array relating buffer position and last use time
  long *lastUseTimeLRUK; // Array relating buffer position, last K use times.
  long timeCounter; // Time counter to update *lastUseTime. Increase each pinPage.
  int K; // LRU-K K value
  int *clockBits; // Time counter to update *lastUseTime. Increase each pinPage.
  int *frequenceCount; // Time counter to update *lastUseTime. Increase each pinPage.
} BM_Buffer;

// convenience macros
#define MAKE_POOL()					\
  ((BM_BufferPool *) malloc (sizeof(BM_BufferPool)))

#define MAKE_PAGE_HANDLE()				\
  ((BM_PageHandle *) malloc (sizeof(BM_PageHandle)))

// Buffer Manager Interface Pool Handling
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName, 
		  const int numPages, ReplacementStrategy strategy, 
		  void *stratData);
RC shutdownBufferPool(BM_BufferPool *const bm);
RC forceFlushPool(BM_BufferPool *const bm);

// Buffer Manager Interface Access Pages
RC markDirty (BM_BufferPool *const bm, BM_PageHandle *const page);
RC unpinPage (BM_BufferPool *const bm, BM_PageHandle *const page);
RC forcePage (BM_BufferPool *const bm, BM_PageHandle *const page);
RC pinPage (BM_BufferPool *const bm, BM_PageHandle *const page, 
	    const PageNumber pageNum);

// Statistics Interface
PageNumber *getFrameContents (BM_BufferPool *const bm);
bool *getDirtyFlags (BM_BufferPool *const bm);
int *getFixCounts (BM_BufferPool *const bm);
int getNumReadIO (BM_BufferPool *const bm);
int getNumWriteIO (BM_BufferPool *const bm);

//Added functions ASSIGNMENT 2
int findPageIndex (int numPage, int totalPages, PageNumber *pageIndex);
int searchInsertPosition(int currentPos, int *fixCount, int totalPages);
int searchLowerTime(long *lastUseTime, int *fixCount, int totalPages);
int searchLowerTimeK(long *lastUseTimeLRUK, int *fixCount, int totalPages, int K, long now);
int searchBitZero(int currentPos, int *fixCount, int *clockBits, int totalPages);
int searchLowerFrequence(int *frequenceCount, int *fixCount, int totalPages);
void addHeap(long *array, int numPage, int K, long value);

#endif
